# Ergo Names Python SDK

Converted to importable library coming soon

### Documentation

#### Resolving ErgoNames

```python
name = "~balb"
address = resolve_ergoname(name)
```

```
3WwKzFjZGrtKAV7qSCoJsZK9iJhLLrUa3uwd4yw52bVtDVv6j5TL
```

### Contribute

If you wish to contribute, make a pull request!